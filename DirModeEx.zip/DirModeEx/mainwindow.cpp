// DirModeEx: Windows 7 兼容的目录/文件管理示例
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSplitter>
#include <QTreeView>
#include <QTableView>
#include <QHeaderView>
#include <QFileSystemModel>
#include <QLineEdit>
#include <QComboBox>
#include <QCheckBox>
#include <QSpinBox>
#include <QToolBar>
#include <QAction>
#include <QFileDialog>
#include <QInputDialog>
#include <QMessageBox>
#include <QStatusBar>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QScrollArea>
#include <QLabel>
#include <QPushButton>
#include <QTextEdit>
#include <QShortcut>
#include <QSettings>
#include <QMimeData>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QProcess>
#include <QProgressBar>
#include <QApplication>
#include <QDirIterator>
#include <QtConcurrent>
#include <QDesktopServices>
#include <QUrl>
#include "text_extractor.h"
#include "language_settings.h"
#include "csv_lang_plugin.h"
#include "csv_parser.h"
#include <QMap>

namespace {
struct ExtractMapFn {
    QString mode;
    QMap<QString, QString> defines;
    QString typeName;
    bool keepEsc;
    QList<ExtractedBlock> operator()(const QString &fpath) const {
        QList<ExtractedBlock> res;
        QString text = TextExtractor::readTextFile(fpath);
        QString t = (mode == QStringLiteral("effective")) ? TextExtractor::preprocess(text, defines) : text;
        auto b = TextExtractor::extractBlocks(t, fpath, typeName, keepEsc);
        res.append(b);
        return res;
    }
};
struct ExtractReduceFn {
    void operator()(QList<ExtractedBlock> &result, const QList<ExtractedBlock> &mapped) const {
        result.append(mapped);
    }
};
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // 初始化异步语言列发现 watcher
    m_langDiscoverWatcher = new QFutureWatcher<QStringList>(this);
    connect(m_langDiscoverWatcher, &QFutureWatcher<QStringList>::finished, this, [this]
            {
                QStringList langCols = m_langDiscoverWatcher->future().result();
                if (langCols.isEmpty())
                    langCols = TextExtractor::defaultLanguageColumns();
                applyLanguageChecks(langCols);
                QApplication::restoreOverrideCursor();
                statusBar()->clearMessage();
            });
    // 初始化提取流程的并发监视器与进度回调
    m_extractWatcher = new QFutureWatcher<QList<ExtractedBlock>>(this);
    connect(m_extractWatcher, &QFutureWatcher<QList<ExtractedBlock>>::progressRangeChanged, this, [this](int min, int max)
            {
                if (m_extractProgress)
                {
                    m_extractProgress->setMinimum(min);
                    m_extractProgress->setMaximum(max);
                }
            });
    connect(m_extractWatcher, &QFutureWatcher<QList<ExtractedBlock>>::progressValueChanged, this, [this](int value)
            {
                if (m_extractProgress)
                    m_extractProgress->setValue(value);
            });
    connect(m_extractWatcher, &QFutureWatcher<QList<ExtractedBlock>>::finished, this, [this]
            {
                QList<ExtractedBlock> all = m_extractWatcher->result();
                bool ok = TextExtractor::writeCsv(m_extractOutCsv, all, m_extractLangCols, m_extractLiteralCols, m_extractReplaceCommaFlag);
                QApplication::restoreOverrideCursor();
                statusBar()->clearMessage();
                if (m_extractProgress)
                    m_extractProgress->setValue(m_extractProgress->maximum());
                if (ok)
                {
                    log(QStringLiteral("提取完成：%1，共 %2 项").arg(m_extractOutCsv).arg(all.size()));
                    QMessageBox::information(this, QStringLiteral("提取完成"), QStringLiteral("CSV 已生成：%1\n共提取 %2 项").arg(m_extractOutCsv).arg(all.size()));
                }
                else
                {
                    QMessageBox::critical(this, QStringLiteral("提取失败"), QStringLiteral("写入CSV失败，请检查路径权限。"));
                }
            });
    setupUiContent();
}

MainWindow::~MainWindow()
{
    if (m_logStream)
    {
        delete m_logStream;
        m_logStream = nullptr;
    }
    if (m_logFile)
    {
        m_logFile->close();
        delete m_logFile;
        m_logFile = nullptr;
    }
    delete ui;
}

void MainWindow::setupUiContent()
{
    setWindowTitle(QStringLiteral("DirModeEx - C++/Qt (Win7)"));

    // 日志文件
    QDir().mkpath(QStringLiteral("logs"));
    m_logFile = new QFile(QStringLiteral("logs/dir_app.log"), this);
    if (m_logFile->open(QIODevice::Append | QIODevice::Text))
    {
        m_logStream = new QTextStream(m_logFile);
        log(QStringLiteral("=== 应用启动 ==="));
    }

    // 顶部路径栏与工具栏
    m_toolbar = addToolBar(QStringLiteral("操作"));
    m_toolbar->setMovable(false);
    m_pathEdit = new QLineEdit(this);
    m_pathEdit->setPlaceholderText(QStringLiteral("输入路径并回车，例如 C:/Users"));
    connect(m_pathEdit, SIGNAL(returnPressed()), this, SLOT(onPathReturnPressed()));
    QWidget *spacer = new QWidget(this);
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

    actRefresh = m_toolbar->addAction(QStringLiteral("刷新"), this, SLOT(onRefresh()));
    actNewFolder = m_toolbar->addAction(QStringLiteral("新建文件夹"), this, SLOT(onNewFolder()));
    actRename = m_toolbar->addAction(QStringLiteral("重命名"), this, SLOT(onRename()));
    actDelete = m_toolbar->addAction(QStringLiteral("删除"), this, SLOT(onDelete()));
    actCopy = m_toolbar->addAction(QStringLiteral("复制到..."), this, SLOT(onCopy()));
    actMove = m_toolbar->addAction(QStringLiteral("移动到..."), this, SLOT(onMove()));
    m_toolbar->addWidget(spacer);
    m_toolbar->addWidget(m_pathEdit);

    // 中心区域：目录树 + 文件表
    QSplitter *splitter = new QSplitter(this);
    m_tabs = new QTabWidget(this);
    setCentralWidget(m_tabs);

    m_dirModel = new QFileSystemModel(splitter);
    m_dirModel->setFilter(QDir::AllDirs | QDir::NoDotAndDotDot);
    m_dirModel->setReadOnly(false);
    m_dirModel->setRootPath(QLatin1String(""));

    m_fileModel = new QFileSystemModel(splitter);
    m_fileModel->setFilter(QDir::AllEntries | QDir::NoDot);
    m_fileModel->setReadOnly(false);
    m_fileModel->setRootPath(QLatin1String(""));

    m_tree = new QTreeView(splitter);
    m_tree->setModel(m_dirModel);
    m_tree->setHeaderHidden(true);
    m_tree->setAnimated(true);
    m_tree->setIndentation(16);

    m_table = new QTableView(splitter);
    m_table->setModel(m_fileModel);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::ExtendedSelection);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->setSortingEnabled(true);
    connect(m_table, SIGNAL(doubleClicked(QModelIndex)), this, SLOT(onTableDoubleClicked(QModelIndex)));

    // 同步选择更改
    connect(m_tree->selectionModel(), SIGNAL(currentChanged(QModelIndex, QModelIndex)), this, SLOT(onTreeSelectionChanged(QModelIndex, QModelIndex)));

    // 将现有目录树+文件表嵌入“提取CSV”页
    QWidget *extractPage = new QWidget(this);
    QVBoxLayout *extractLayout = new QVBoxLayout(extractPage);
    // 顶部提示与浏览按钮
    QWidget *extractTop = new QWidget(extractPage);
    QHBoxLayout *extractTopLayout = new QHBoxLayout(extractTop);
    QLabel *extractHint = new QLabel(QStringLiteral("选择项目目录，配置参数后执行提取"), extractTop);
    m_browseProjectBtn = new QPushButton(QStringLiteral("浏览..."), extractTop);
    connect(m_browseProjectBtn, &QPushButton::clicked, this, [this]
            {
        QString dir = QFileDialog::getExistingDirectory(this, QStringLiteral("选择项目目录"), QDir::homePath());
        if (!dir.isEmpty()) { m_pathEdit->setText(dir); setCurrentPath(dir); } });
    extractTopLayout->addWidget(extractHint);
    extractTopLayout->addStretch();
    extractTopLayout->addWidget(m_browseProjectBtn);
    extractLayout->addWidget(extractTop);
    // 主体 splitter
    extractLayout->addWidget(splitter, 1);
    // 选项与执行按钮
    QWidget *extractBottom = new QWidget(extractPage);
    QVBoxLayout *extractBottomLayout = new QVBoxLayout(extractBottom);
    // 行1：类型、模式、保留转义
    QWidget *exRow1 = new QWidget(extractBottom);
    QHBoxLayout *exH1 = new QHBoxLayout(exRow1);
    m_extractTypeCombo = new QComboBox(exRow1);
    m_extractTypeCombo->addItems(QStringList{QStringLiteral("动态文本")});
    m_extractModeCombo = new QComboBox(exRow1);
    m_extractModeCombo->addItems(QStringList{QStringLiteral("effective"), QStringLiteral("all")});
    m_extractKeepEscapes = new QCheckBox(QStringLiteral("保留转义字符"), exRow1);
    m_extractKeepEscapes->setChecked(true);
    m_extractKeepEscapes->setToolTip(QStringLiteral("提取时保留原始转义，如\\xNN、\\n、\\t 等"));
    exH1->addWidget(new QLabel(QStringLiteral("类型:")));
    exH1->addWidget(m_extractTypeCombo);
    exH1->addSpacing(12);
    exH1->addWidget(new QLabel(QStringLiteral("模式:")));
    exH1->addWidget(m_extractModeCombo);
    exH1->addSpacing(12);
    exH1->addWidget(m_extractKeepEscapes);
    exH1->addStretch();
    // 行2：扩展名、宏定义、执行按钮
    QWidget *exRow2 = new QWidget(extractBottom);
    QHBoxLayout *exH2 = new QHBoxLayout(exRow2);
    m_extractExtsEdit = new QLineEdit(exRow2);
    m_extractExtsEdit->setPlaceholderText(QStringLiteral(".h,.hpp,.c,.cpp"));
    m_extractExtsEdit->setText(QStringLiteral(".h,.hpp,.c,.cpp"));
    m_extractDefinesEdit = new QLineEdit(exRow2);
    m_extractDefinesEdit->setPlaceholderText(QStringLiteral("示例: FOO=1;BAR;BAZ=hello"));
    m_extractRunBtn = new QPushButton(QStringLiteral("从代码提取到CSV"), exRow2);
    connect(m_extractRunBtn, SIGNAL(clicked()), this, SLOT(onExtractRun()));
    m_extractProgress = new QProgressBar(exRow2);
    m_extractProgress->setMinimum(0);
    m_extractProgress->setMaximum(100);
    m_extractProgress->setValue(0);
    exH2->addWidget(new QLabel(QStringLiteral("扩展:")));
    exH2->addWidget(m_extractExtsEdit, 1);
    exH2->addSpacing(12);
    exH2->addWidget(new QLabel(QStringLiteral("宏定义:")));
    exH2->addWidget(m_extractDefinesEdit, 1);
    exH2->addStretch();
    exH2->addWidget(m_extractProgress);
    exH2->addWidget(m_extractRunBtn);
    // 行3：保留原文语言列配置
    QWidget *exRow3 = new QWidget(extractBottom);
    QHBoxLayout *exH3 = new QHBoxLayout(exRow3);
    m_extractUtf8Literal = new QCheckBox(QStringLiteral("仅指定语言保留原文，其余写为\\xNN"), exRow3);
    m_extractUtf8Literal->setChecked(true);
    m_extractUtf8ColsEdit = new QLineEdit(exRow3);
    m_extractUtf8ColsEdit->setPlaceholderText(QStringLiteral("例如: text_cn,text_en"));
    m_extractUtf8ColsEdit->setText(QStringLiteral("text_cn,text_en"));
    m_extractReplaceComma = new QCheckBox(QStringLiteral("替换英文逗号为中文逗号"), exRow3);
    m_extractReplaceComma->setToolTip(QStringLiteral("将文本中的 , 替换为 ，，避免CSV处理时误分列或换行"));
    m_extractReplaceComma->setChecked(true);
    exH3->addWidget(m_extractUtf8Literal);
    exH3->addSpacing(12);
    exH3->addWidget(new QLabel(QStringLiteral("保留原文语言列:")));
    exH3->addWidget(m_extractUtf8ColsEdit, 1);
    exH3->addSpacing(12);
    exH3->addWidget(m_extractReplaceComma);
    extractBottomLayout->addWidget(exRow1);
    extractBottomLayout->addWidget(exRow2);
    extractBottomLayout->addWidget(exRow3);
    // 动态语言复选框容器（用于选择保留原文语言）
    m_extractLangBox = new QWidget(extractBottom);
    {
        QVBoxLayout *langLay = new QVBoxLayout(m_extractLangBox);
        langLay->setContentsMargins(0, 0, 0, 0);
        langLay->addWidget(new QLabel(QStringLiteral("选择保留原文语言:")));
        QScrollArea *scroll = new QScrollArea(m_extractLangBox);
        scroll->setWidgetResizable(true);
        QWidget *gridContainer = new QWidget(scroll);
        gridContainer->setObjectName("langGridContainer");
        QGridLayout *grid = new QGridLayout(gridContainer);
        grid->setContentsMargins(0, 0, 0, 0);
        grid->setHorizontalSpacing(12);
        grid->setVerticalSpacing(6);
        scroll->setWidget(gridContainer);
    langLay->addWidget(scroll);
    }
    extractBottomLayout->addWidget(m_extractLangBox);
    extractLayout->addWidget(extractBottom);
    m_tabs->addTab(extractPage, QStringLiteral("提取CSV"));

    // “从CSV生成C”页
    QWidget *genPage = new QWidget(this);
    QVBoxLayout *genLayout = new QVBoxLayout(genPage);
    QWidget *genRow1 = new QWidget(genPage);
    QHBoxLayout *genH1 = new QHBoxLayout(genRow1);
    m_csvInputEdit = new QLineEdit(genPage);
    m_browseCsvBtn = new QPushButton(QStringLiteral("选择CSV..."), genPage);
    connect(m_browseCsvBtn, &QPushButton::clicked, this, [this]
            {
        QString f = QFileDialog::getOpenFileName(this, QStringLiteral("选择CSV"), QDir::homePath(), QStringLiteral("CSV (*.csv)"));
        if (!f.isEmpty()) m_csvInputEdit->setText(f); });
    genH1->addWidget(new QLabel(QStringLiteral("CSV 输入:")));
    genH1->addWidget(m_csvInputEdit, 1);
    genH1->addWidget(m_browseCsvBtn);
    QWidget *genRow2 = new QWidget(genPage);
    QHBoxLayout *genH2 = new QHBoxLayout(genRow2);
    m_cOutputEdit = new QLineEdit(genPage);
    m_browseCOutBtn = new QPushButton(QStringLiteral("选择C输出..."), genPage);
    connect(m_browseCOutBtn, &QPushButton::clicked, this, [this]
            {
        QString f = QFileDialog::getSaveFileName(this, QStringLiteral("选择C输出"), QDir::homePath()+QStringLiteral("/generated.c"), QStringLiteral("C (*.c)"));
        if (!f.isEmpty()) m_cOutputEdit->setText(f); });
    genH2->addWidget(new QLabel(QStringLiteral("C 输出:")));
    genH2->addWidget(m_cOutputEdit, 1);
    genH2->addWidget(m_browseCOutBtn);
    // 生成选项行
    QWidget *genOpts1 = new QWidget(genPage);
    QHBoxLayout *genO1 = new QHBoxLayout(genOpts1);
    m_genNoStatic = new QCheckBox("去除static", genOpts1);
    m_genEmitRegistry = new QCheckBox("生成注册表数组", genOpts1);
    m_genRegistryNameEdit = new QLineEdit(genOpts1);
    m_genRegistryNameEdit->setPlaceholderText(QStringLiteral("注册表数组名称，如 text_registry"));
    genO1->addWidget(m_genNoStatic);
    genO1->addSpacing(12);
    genO1->addWidget(m_genEmitRegistry);
    genO1->addWidget(m_genRegistryNameEdit, 1);

    QWidget *genOpts2 = new QWidget(genPage);
    QHBoxLayout *genO2 = new QHBoxLayout(genOpts2);
    m_genUtf8Literal = new QCheckBox("UTF-8直写", genOpts2);
    m_genUtf8ColsEdit = new QLineEdit(genOpts2);
    m_genUtf8ColsEdit->setPlaceholderText(QStringLiteral("直写列名（逗号分隔），如 cn,en"));
    m_genNullSentinel = new QCheckBox("末尾NULL哨兵", genOpts2);
    m_genNullSentinel->setChecked(true);
    m_genVerbatim = new QCheckBox("保留原样(不转为十六进制)", genOpts2);
    m_genVerbatim->setChecked(true);
    m_genFillMissingWithEnglish = new QCheckBox("缺失语言用英文填充", genOpts2);
    m_genFillMissingWithEnglish->setChecked(true);
    genO2->addWidget(m_genUtf8Literal);
    genO2->addWidget(m_genUtf8ColsEdit, 1);
    genO2->addSpacing(12);
    genO2->addWidget(m_genNullSentinel);
    genO2->addSpacing(12);
    genO2->addWidget(m_genVerbatim);
    genO2->addSpacing(12);
    genO2->addWidget(m_genFillMissingWithEnglish);

    QWidget *genOpts3 = new QWidget(genPage);
    QHBoxLayout *genO3 = new QHBoxLayout(genOpts3);
    m_genAnnotateCombo = new QComboBox(genOpts3);
    m_genAnnotateCombo->addItems({"none", "names", "indices"});
    m_genAnnotateCombo->setCurrentText("indices");
    m_genPerLineSpin = new QSpinBox(genOpts3);
    m_genPerLineSpin->setRange(1, 12);
    m_genPerLineSpin->setValue(1);
    genO3->addWidget(new QLabel(QStringLiteral("注释模式:")));
    genO3->addWidget(m_genAnnotateCombo);
    genO3->addSpacing(12);
    genO3->addWidget(new QLabel(QStringLiteral("每行条目:")));
    genO3->addWidget(m_genPerLineSpin);

    m_generateRunBtn = new QPushButton(QStringLiteral("生成"), genPage);
    connect(m_generateRunBtn, SIGNAL(clicked()), this, SLOT(onGenerateRun()));
    genLayout->addWidget(genRow1);
    genLayout->addWidget(genRow2);
    genLayout->addWidget(genOpts1);
    genLayout->addWidget(genOpts2);
    genLayout->addWidget(genOpts3);
    genLayout->addStretch();
    genLayout->addWidget(m_generateRunBtn);
    m_tabs->addTab(genPage, "从CSV生成C");

    // “CSV 翻译导入”页
    QWidget *csvPage = new QWidget(this);
    QVBoxLayout *csvLayout = new QVBoxLayout(csvPage);
    QWidget *csvRow1 = new QWidget(csvPage);
    QHBoxLayout *csvH1 = new QHBoxLayout(csvRow1);
    m_csvProjEdit = new QLineEdit(csvRow1);
    m_csvProjEdit->setPlaceholderText(QStringLiteral("选择项目根目录"));
    m_csvProjBrowseBtn = new QPushButton(QStringLiteral("浏览..."), csvRow1);
    connect(m_csvProjBrowseBtn, SIGNAL(clicked()), this, SLOT(onBrowseCsvProject()));
    csvH1->addWidget(new QLabel(QStringLiteral("项目根目录:")));
    csvH1->addWidget(m_csvProjEdit, 1);
    csvH1->addWidget(m_csvProjBrowseBtn);
    QWidget *csvRow2 = new QWidget(csvPage);
    QHBoxLayout *csvH2 = new QHBoxLayout(csvRow2);
    m_csvFileEdit = new QLineEdit(csvRow2);
    m_csvFileEdit->setPlaceholderText(QStringLiteral("选择CSV文件"));
    m_csvFileBrowseBtn = new QPushButton(QStringLiteral("选择CSV..."), csvRow2);
    connect(m_csvFileBrowseBtn, SIGNAL(clicked()), this, SLOT(onBrowseCsvFile()));
    csvH2->addWidget(new QLabel(QStringLiteral("CSV 文件:")));
    csvH2->addWidget(m_csvFileEdit, 1);
    csvH2->addWidget(m_csvFileBrowseBtn);
    QWidget *csvRow3 = new QWidget(csvPage);
    QHBoxLayout *csvH3 = new QHBoxLayout(csvRow3);
    m_csvProgress = new QProgressBar(csvRow3);
    m_csvProgress->setMinimum(0);
    m_csvProgress->setMaximum(100);
    m_csvProgress->setValue(0);
    m_csvRunBtn = new QPushButton(QStringLiteral("执行导入"), csvRow3);
    m_csvExportLogBtn = new QPushButton(QStringLiteral("导出日志"), csvRow3);
    connect(m_csvRunBtn, SIGNAL(clicked()), this, SLOT(onRunCsvImport()));
    connect(m_csvExportLogBtn, SIGNAL(clicked()), this, SLOT(onExportCsvLog()));
    csvH3->addWidget(new QLabel(QStringLiteral("进度:")));
    csvH3->addWidget(m_csvProgress, 1);
    csvH3->addStretch();
    csvH3->addWidget(m_csvRunBtn);
    csvH3->addWidget(m_csvExportLogBtn);
    m_csvReportView = new QTextEdit(csvPage);
    m_csvReportView->setReadOnly(true);
    csvLayout->addWidget(csvRow1);
    csvLayout->addWidget(csvRow2);
    csvLayout->addWidget(csvRow3);
    csvLayout->addWidget(m_csvReportView, 1);
    m_tabs->addTab(csvPage, "CSV翻译导入");

    // “项目设置：语言”页
    QWidget *projPage = new QWidget(this);
    QVBoxLayout *projLayout = new QVBoxLayout(projPage);
    QWidget *prTop = new QWidget(projPage);
    QHBoxLayout *prH1 = new QHBoxLayout(prTop);
    m_projRootEdit = new QLineEdit(prTop);
    m_projRootEdit->setPlaceholderText(QStringLiteral("选择项目根目录，例如 e:/code/project"));
    m_projBrowseRootBtn = new QPushButton(QStringLiteral("浏览..."), prTop);
    connect(m_projBrowseRootBtn, SIGNAL(clicked()), this, SLOT(onBrowseProjectRoot()));
    prH1->addWidget(new QLabel(QStringLiteral("项目根目录:")));
    prH1->addWidget(m_projRootEdit, 1);
    prH1->addWidget(m_projBrowseRootBtn);
    QWidget *prRow2 = new QWidget(projPage);
    QHBoxLayout *prH2 = new QHBoxLayout(prRow2);
    m_projNewLangEdit = new QLineEdit(prRow2);
    m_projNewLangEdit->setPlaceholderText(QStringLiteral("新语言代码，例如: fr"));
    m_projInitLangBtn = new QPushButton(QStringLiteral("一键初始化新语言"), prRow2);
    connect(m_projInitLangBtn, SIGNAL(clicked()), this, SLOT(onInitNewLanguage()));
    m_projUndoBtn = new QPushButton(QStringLiteral("撤销上次初始化"), prRow2);
    connect(m_projUndoBtn, SIGNAL(clicked()), this, SLOT(onUndoLastInit()));
    m_projFillEnglishBtn = new QPushButton(QStringLiteral("一键补齐英文缺失项"), prRow2);
    connect(m_projFillEnglishBtn, SIGNAL(clicked()), this, SLOT(onFillEnglishMissing()));
    prH2->addWidget(new QLabel(QStringLiteral("语言代码:")));
    prH2->addWidget(m_projNewLangEdit, 1);
    prH2->addWidget(m_projInitLangBtn);
    prH2->addWidget(m_projUndoBtn);
    prH2->addWidget(m_projFillEnglishBtn);
    QWidget *prRow3 = new QWidget(projPage);
    QHBoxLayout *prH3 = new QHBoxLayout(prRow3);
    m_projLogLabel = new QLabel(QStringLiteral("日志: logs/lang_init.log"), prRow3);
    prH3->addWidget(m_projLogLabel);
    prH3->addStretch();
    projLayout->addWidget(new QLabel(QStringLiteral("新增语言将插入在 p_text_other 之前，类型与约束保持一致，并以英文为模板初始化（保留格式与占位符），同时标记为待翻译。支持批量处理与撤销。")));
    projLayout->addWidget(prTop);
    projLayout->addWidget(prRow2);
    projLayout->addWidget(prRow3);
    projLayout->addStretch();
    m_tabs->addTab(projPage, "项目设置");

    // “设置”页（显示文档）
    QWidget *settingsPage = new QWidget(this);
    QVBoxLayout *settingsLayout = new QVBoxLayout(settingsPage);
    m_settingsInfo = new QTextEdit(settingsPage);
    m_settingsInfo->setReadOnly(true);
    QFile docFile("../docs/ui_paging.md");
    if (docFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        m_settingsInfo->setPlainText(QString::fromUtf8(docFile.readAll()));
        docFile.close();
    }
    else
    {
        m_settingsInfo->setPlainText("分页式界面说明未找到，路径 ../docs/ui_paging.md");
    }
    settingsLayout->addWidget(m_settingsInfo);
    m_tabs->addTab(settingsPage, "设置");

    // “日志”页
    QWidget *logsPage = new QWidget(this);
    QVBoxLayout *logsLayout = new QVBoxLayout(logsPage);
    m_logView = new QTextEdit(logsPage);
    m_logView->setReadOnly(true);
    logsLayout->addWidget(m_logView);
    m_tabs->addTab(logsPage, "日志");

    // 快捷键（Qt5 需通过信号连接激活事件）
    QShortcut *scNext = new QShortcut(QKeySequence("Ctrl+Tab"), this);
    QObject::connect(scNext, &QShortcut::activated, this, [this]
                     { m_tabs->setCurrentIndex((m_tabs->currentIndex() + 1) % m_tabs->count()); });
    QShortcut *scPrev = new QShortcut(QKeySequence("Ctrl+Shift+Tab"), this);
    QObject::connect(scPrev, &QShortcut::activated, this, [this]
                     { m_tabs->setCurrentIndex((m_tabs->currentIndex() - 1 + m_tabs->count()) % m_tabs->count()); });

    // 面包屑（标题随页签变化）
    connect(m_tabs, &QTabWidget::currentChanged, this, [this](int idx)
            {
        setWindowTitle(QString("DirModeEx - %1").arg(m_tabs->tabText(idx)));
        QSettings s("DirModeEx", "DirApp");
        s.setValue("lastTab", idx); });

    // 允许拖拽进入
    setAcceptDrops(true);

    // 恢复上次页签
    QSettings s("DirModeEx", "DirApp");
    int last = s.value("lastTab", 0).toInt();
    if (last >= 0 && last < m_tabs->count())
        m_tabs->setCurrentIndex(last);

    // 初始路径
    setCurrentPath(QDir::homePath());
}

void MainWindow::log(const QString &msg)
{
    statusBar()->showMessage(msg, 3000);
    if (m_logView)
    {
        m_logView->append(msg);
    }
    if (m_logStream)
    {
        (*m_logStream) << QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd hh:mm:ss"))
                       << QStringLiteral(" | ") << msg << QStringLiteral("\n");
        m_logStream->flush();
    }
}

void MainWindow::setCurrentPath(const QString &path)
{
    QModelIndex dirIndex = m_dirModel->index(path);
    if (dirIndex.isValid())
    {
        m_tree->setCurrentIndex(dirIndex);
        m_tree->expand(dirIndex);
        m_table->setRootIndex(m_fileModel->setRootPath(path));
        m_pathEdit->setText(path);
        log(QStringLiteral("进入目录: ") + path);
        // 根据新路径刷新“保留原文语言”复选框
        refreshExtractLanguageChecks();
    }
    else
    {
        QMessageBox::warning(this, QStringLiteral("路径无效"), QStringLiteral("无法访问路径：%1").arg(path));
    }
}

QString MainWindow::currentDirPath() const
{
    QModelIndex idx = m_tree->currentIndex();
    return m_dirModel->filePath(idx);
}

QStringList MainWindow::selectedFilePaths() const
{
    QStringList paths;
    foreach (const QModelIndex &idx, m_table->selectionModel()->selectedRows())
    {
        paths << m_fileModel->filePath(idx);
    }
    return paths;
}

void MainWindow::onPathReturnPressed()
{
    setCurrentPath(m_pathEdit->text());
}

void MainWindow::onTreeSelectionChanged(const QModelIndex &current, const QModelIndex & /*previous*/)
{
    const QString path = m_dirModel->filePath(current);
    m_table->setRootIndex(m_fileModel->setRootPath(path));
    m_pathEdit->setText(path);
}

void MainWindow::onTableDoubleClicked(const QModelIndex &index)
{
    const QString p = m_fileModel->filePath(index);
    QFileInfo info(p);
    if (info.isDir())
    {
        setCurrentPath(p);
    }
    else
    {
        // 打开文件所在目录并选择
        log(QStringLiteral("选中文件：%1").arg(p));
    }
}

void MainWindow::onRefresh()
{
    const QString p = currentDirPath();
    // QFileSystemModel 在 Qt5 中没有 refresh()，通过重设 rootPath 触发重载
    m_dirModel->setRootPath(m_dirModel->rootPath());
    m_fileModel->setRootPath(m_fileModel->rootPath());
    setCurrentPath(p);
    log(QStringLiteral("已刷新"));
}

void MainWindow::onExtractRun()
{
    const QString dir = m_pathEdit ? m_pathEdit->text() : QString();
    const QString type = m_extractTypeCombo ? m_extractTypeCombo->currentText() : QString();
    const bool keepEsc = m_extractKeepEscapes && m_extractKeepEscapes->isChecked();
    if (dir.isEmpty())
    {
        QMessageBox::warning(this, QStringLiteral("提取"), QStringLiteral("请选择或输入项目根目录。"));
        return;
    }
    const QString outCsv = QDir(dir).absoluteFilePath(QStringLiteral("ty_text_out.csv"));
    const QString mode = m_extractModeCombo ? m_extractModeCombo->currentText() : QStringLiteral("effective");
    log(QStringLiteral("[提取] 目录=%1, 输出=%2, 模式=%3, 保留转义=%4").arg(dir, outCsv, mode).arg(keepEsc ? QStringLiteral("是") : QStringLiteral("否")));
    // 扩展名
    QStringList exts;
    if (m_extractExtsEdit && !m_extractExtsEdit->text().trimmed().isEmpty())
    {
        for (const QString &p : m_extractExtsEdit->text().split(QLatin1Char(','), Qt::SkipEmptyParts))
        {
            exts << p.trimmed();
        }
    }
    if (exts.isEmpty())
        exts = QStringList{QLatin1String(".h"), QLatin1String(".hpp"), QLatin1String(".c"), QLatin1String(".cpp")};
    // 宏定义解析 A=1;B;C=hello
    QMap<QString, QString> defines;
    if (m_extractDefinesEdit && !m_extractDefinesEdit->text().trimmed().isEmpty())
    {
    for (const QString &item : m_extractDefinesEdit->text().split(QLatin1Char(';'), Qt::SkipEmptyParts))
        {
            QString t = item.trimmed();
            if (t.isEmpty())
                continue;
            int eq = t.indexOf('=');
            if (eq >= 0)
            {
                defines.insert(t.left(eq).trimmed(), t.mid(eq + 1).trimmed());
            }
            else
            {
                defines.insert(t, QString());
            }
        }
    }
    const QString typeName = "_Tr_TEXT";
    QStringList langCols = TextExtractor::discoverLanguageColumns(dir, exts, typeName);
    // 按需：保留原文语言列（可配置），其余写为UTF-8十六进制转义
    QStringList literalCols;
    if (m_extractUtf8Literal && m_extractUtf8Literal->isChecked())
    {
        // 优先使用动态复选框的选择结果
        if (!m_extractLangChecks.isEmpty())
        {
            for (QCheckBox *cb : m_extractLangChecks)
            {
                if (cb && cb->isChecked())
                    literalCols << cb->text().trimmed();
            }
        }
        // 如果复选框未提供选择，则回退到文本输入
        if (literalCols.isEmpty())
        {
            if (m_extractUtf8ColsEdit && !m_extractUtf8ColsEdit->text().trimmed().isEmpty())
            {
    for (const QString &c : m_extractUtf8ColsEdit->text().split(QLatin1Char(','), Qt::SkipEmptyParts))
                {
                    literalCols << c.trimmed();
                }
            }
            else
            {
                // 默认保留中文/英文
                literalCols << QStringLiteral("text_cn") << QStringLiteral("text_en");
            }
        }
    }
    else
    {
        // 未勾选时：全部列保留原文（不进行十六进制转义）
        literalCols = langCols;
    }
    // 收集文件列表
    QStringList files;
    QDirIterator it(dir, QDir::Files, QDirIterator::Subdirectories);
    auto matchExt = [&](const QString &fn)
    { for (const QString &e : exts) if (fn.toLower().endsWith(e.toLower())) return true; return false; };
    while (it.hasNext())
    {
        const QString f = it.next();
        if (matchExt(QFileInfo(f).fileName()))
            files << f;
    }
    if (files.isEmpty())
    {
        QMessageBox::warning(this, QStringLiteral("提取"), QStringLiteral("未找到匹配的源文件。"));
        return;
    }
    // 记录上下文，启动并发映射归约
    m_extractOutCsv = outCsv;
    m_extractLangCols = langCols;
    m_extractLiteralCols = literalCols;
    m_extractReplaceCommaFlag = m_extractReplaceComma && m_extractReplaceComma->isChecked();
    statusBar()->showMessage(QStringLiteral("正在提取 %1 个文件…").arg(files.size()));
    QApplication::setOverrideCursor(Qt::BusyCursor);
    ExtractMapFn mapFn{mode, defines, typeName, keepEsc};
    ExtractReduceFn reduceFn{};
    auto future = QtConcurrent::run([files, mapFn, reduceFn]() {
        QList<ExtractedBlock> out;
        for (const QString &f : files)
        {
            QList<ExtractedBlock> mapped = mapFn(f);
            reduceFn(out, mapped);
        }
        return out;
    });
    m_extractWatcher->setFuture(future);
}

void MainWindow::onGenerateRun()
{
    const QString csv = m_csvInputEdit ? m_csvInputEdit->text() : QString();
    const QString outc = m_cOutputEdit ? m_cOutputEdit->text() : QString();
    if (csv.isEmpty())
    {
        QMessageBox::warning(this, QStringLiteral("生成"), QStringLiteral("请选择或输入CSV路径。"));
        return;
    }
    if (outc.isEmpty())
    {
        QMessageBox::warning(this, QStringLiteral("生成"), QStringLiteral("请选择或输入C输出文件路径。"));
        return;
    }
    QString headerOut = QDir(qApp->applicationDirPath()).absoluteFilePath(QStringLiteral("../include/generated_text_vars_dynamic.h"));
    log(QStringLiteral("[生成] CSV=%1, C=%2, 头文件=%3").arg(csv, outc, headerOut));
    const bool noStatic = m_genNoStatic && m_genNoStatic->isChecked();
    const bool regEmit = m_genEmitRegistry && m_genEmitRegistry->isChecked();
    const QString regName = m_genRegistryNameEdit ? m_genRegistryNameEdit->text().trimmed() : QString();
    const bool utf8Lit = m_genUtf8Literal && m_genUtf8Literal->isChecked();
    QStringList litCols;
    if (utf8Lit && m_genUtf8ColsEdit && !m_genUtf8ColsEdit->text().trimmed().isEmpty())
    {
        for (const QString &c : m_genUtf8ColsEdit->text().split(QLatin1Char(','), Qt::SkipEmptyParts))
            litCols << c.trimmed();
    }
    const bool nullSent = m_genNullSentinel && m_genNullSentinel->isChecked();
    const bool verbatim = m_genVerbatim && m_genVerbatim->isChecked();
    const QString annotate = m_genAnnotateCombo ? m_genAnnotateCombo->currentText() : QString("names");
    const int perLine = m_genPerLineSpin ? m_genPerLineSpin->value() : 1;
    const bool fillEng = m_genFillMissingWithEnglish && m_genFillMissingWithEnglish->isChecked();
    QString typeName = "_Tr_TEXT";
    QString code = TextExtractor::generateCFromCsv(
        csv,
        typeName,
        outc,
        headerOut,
        noStatic,
        regEmit,
        regName,
        utf8Lit,
        fillEng,
        nullSent,
        verbatim,
        litCols,
        annotate,
        perLine,
        QMap<QString, QPair<QString, QString>>(),
        QString());
    if (!code.isEmpty())
    {
        log(QStringLiteral("生成完成：%1 和 %2").arg(outc, headerOut));
        QMessageBox::information(this, QStringLiteral("生成完成"), QStringLiteral("已生成：\n%1\n%2").arg(outc, headerOut));
    }
    else
    {
        QMessageBox::critical(this, QStringLiteral("生成失败"), QStringLiteral("生成内容为空，请检查CSV格式。"));
    }
}

void MainWindow::onBrowseProjectRoot()
{
    QString dir = QFileDialog::getExistingDirectory(this, QStringLiteral("选择项目根目录"), QDir::homePath());
    if (!dir.isEmpty())
        m_projRootEdit->setText(dir);
}

void MainWindow::onInitNewLanguage()
{
    QString root = m_projRootEdit ? m_projRootEdit->text().trimmed() : QString();
    QString code = m_projNewLangEdit ? m_projNewLangEdit->text().trimmed() : QString();
    if (root.isEmpty())
    {
    QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请先选择项目根目录"));
        return;
    }
    if (code.isEmpty())
    {
    QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请输入新语言代码，例如 fr"));
        return;
    }
    auto res = ProjectLang::addLanguageAndInitialize(root, code);
    log(res.message);
    if (!res.logPath.isEmpty() && m_projLogLabel)
        m_projLogLabel->setText(QString("日志: %1").arg(res.logPath));
    if (res.success)
    {
        QMessageBox::information(this, "完成", res.message);
        if (!res.outputDir.isEmpty())
            QDesktopServices::openUrl(QUrl::fromLocalFile(res.outputDir));
    }
    else
    {
    QMessageBox::warning(this, QStringLiteral("未变更"), res.message);
    }
}

void MainWindow::onUndoLastInit()
{
    QString root = m_projRootEdit ? m_projRootEdit->text().trimmed() : QString();
    if (root.isEmpty())
    {
    QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请先选择项目根目录"));
        return;
    }
    auto res = ProjectLang::undoLastInitialization(root);
    log(res.message);
    if (!res.logPath.isEmpty() && m_projLogLabel)
        m_projLogLabel->setText(QString("日志: %1").arg(res.logPath));
    if (res.success)
    {
        QMessageBox::information(this, "撤销完成", res.message);
    }
    else
    {
    QMessageBox::warning(this, QStringLiteral("撤销失败"), res.message);
    }
}

void MainWindow::onFillEnglishMissing()
{
    QString root = m_projRootEdit ? m_projRootEdit->text().trimmed() : QString();
    if (root.isEmpty())
    {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请先选择项目根目录"));
        return;
    }
    auto res = ProjectLang::fillMissingEntriesWithEnglish(root);
    log(res.message);
    if (!res.logPath.isEmpty() && m_projLogLabel)
        m_projLogLabel->setText(QString("日志: %1").arg(res.logPath));
    if (res.success)
    {
        QMessageBox::information(this, QStringLiteral("完成"), res.message);
        if (!res.outputDir.isEmpty())
            QDesktopServices::openUrl(QUrl::fromLocalFile(res.outputDir));
    }
    else
    {
        QMessageBox::warning(this, QStringLiteral("未变更"), res.message);
    }
}

void MainWindow::onBrowseCsvProject()
{
    QString dir = QFileDialog::getExistingDirectory(this, "选择项目根目录", QDir::homePath());
    if (!dir.isEmpty())
        m_csvProjEdit->setText(dir);
}

void MainWindow::onBrowseCsvFile()
{
    QString f = QFileDialog::getOpenFileName(this, "选择CSV", QDir::homePath(), "CSV (*.csv)");
    if (!f.isEmpty())
        m_csvFileEdit->setText(f);
}

void MainWindow::onRunCsvImport()
{
    QString root = m_csvProjEdit ? m_csvProjEdit->text().trimmed() : QString();
    QString csv = m_csvFileEdit ? m_csvFileEdit->text().trimmed() : QString();
    if (root.isEmpty() || csv.isEmpty())
    {
    QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请先选择项目根目录和CSV文件"));
        return;
    }
    m_csvProgress->setValue(5);
    // 默认配置：按值列顺序映射标准语言代码
    QJsonObject cfg;
    QJsonObject map;
    map["cn"] = 0;
    map["en"] = 1;
    map["vi"] = 2;
    map["ko"] = 3;
    map["tr"] = 4;
    map["ru"] = 5;
    map["pt"] = 6;
    map["es"] = 7;
    map["fa"] = 8;
    map["jp"] = 9;
    map["ar"] = 10;
    map["other"] = 11;
    cfg["column_mapping"] = map;
    cfg["dry_run"] = false;
    auto stats = CsvLangPlugin::applyTranslations(root, csv, cfg);
    m_csvProgress->setValue(100);
    QString report = QString("成功: %1\n跳过: %2\n失败: %3\n日志: %4\n差异: %5\n备份: %6")
                         .arg(stats.successCount)
                         .arg(stats.skipCount)
                         .arg(stats.failCount)
                         .arg(stats.logPath)
                         .arg(stats.diffPath)
                         .arg(stats.outputDir);
    m_csvReportView->setPlainText(report);
    log(QStringLiteral("CSV导入完成：成功 %1 跳过 %2 失败 %3").arg(stats.successCount).arg(stats.skipCount).arg(stats.failCount));
    if (!stats.outputDir.isEmpty())
        QDesktopServices::openUrl(QUrl::fromLocalFile(stats.outputDir));
}

void MainWindow::onExportCsvLog()
{
    QMessageBox::information(this, QStringLiteral("日志"), QStringLiteral("日志位于 logs/csv_lang_plugin.log，差异位于 logs/csv_lang_plugin.diff"));
}

// 根据当前目录与扩展，动态发现语言列并刷新复选框
void MainWindow::refreshExtractLanguageChecks()
{
    if (!m_extractLangBox)
        return;
    m_extractLangChecks.clear();
    // 获取当前路径与扩展
    QString dir = currentDirPath();
    if (dir.isEmpty() && m_pathEdit)
        dir = m_pathEdit->text();
    QStringList exts;
    if (m_extractExtsEdit && !m_extractExtsEdit->text().trimmed().isEmpty())
    {
        for (const QString &p : m_extractExtsEdit->text().split(QLatin1Char(','), Qt::SkipEmptyParts))
            exts << p.trimmed();
    }
    if (exts.isEmpty())
        exts = QStringList{QLatin1String(".h"), QLatin1String(".hpp"), QLatin1String(".c"), QLatin1String(".cpp")};
    // 异步发现语言列，避免 UI 卡顿
    statusBar()->showMessage(QStringLiteral("正在扫描语言列..."));
    QApplication::setOverrideCursor(Qt::BusyCursor);
    auto future = QtConcurrent::run(TextExtractor::discoverLanguageColumns, dir, exts, QStringLiteral("_Tr_TEXT"));
    m_langDiscoverWatcher->setFuture(future);
    // 预先准备容器，以便 finished 时直接填充
    // 找到滚动区域中的网格容器
    QWidget *gridContainer = m_extractLangBox->findChild<QWidget *>(QStringLiteral("langGridContainer"));
    QGridLayout *grid = gridContainer ? qobject_cast<QGridLayout *>(gridContainer->layout()) : nullptr;
    if (!gridContainer || !grid)
    {
        // 回退：如果容器缺失，则创建
        QVBoxLayout *langLay = qobject_cast<QVBoxLayout *>(m_extractLangBox->layout());
        if (!langLay)
        {
            langLay = new QVBoxLayout(m_extractLangBox);
            langLay->setContentsMargins(0, 0, 0, 0);
        langLay->addWidget(new QLabel(QStringLiteral("选择保留原文语言:")));
        }
        QScrollArea *scroll = new QScrollArea(m_extractLangBox);
        scroll->setWidgetResizable(true);
        gridContainer = new QWidget(scroll);
        gridContainer->setObjectName("langGridContainer");
        grid = new QGridLayout(gridContainer);
        grid->setContentsMargins(0, 0, 0, 0);
        grid->setHorizontalSpacing(12);
        grid->setVerticalSpacing(6);
        scroll->setWidget(gridContainer);
        langLay->addWidget(scroll);
    }
    // 清空旧项并留待 finished 时填充
    while (grid->count() > 0)
    {
        QLayoutItem *it = grid->takeAt(0);
        if (!it)
            break;
        if (QWidget *w = it->widget())
        {
            delete w;
        }
        delete it;
    }
}

void MainWindow::applyLanguageChecks(const QStringList &langCols)
{
    if (!m_extractLangBox)
        return;
    QWidget *gridContainer = m_extractLangBox->findChild<QWidget *>(QStringLiteral("langGridContainer"));
    QGridLayout *grid = gridContainer ? qobject_cast<QGridLayout *>(gridContainer->layout()) : nullptr;
    if (!gridContainer || !grid)
        return;
    const int cols = 4;
    int idx = 0;
    for (const QString &col : langCols)
    {
        QCheckBox *cb = new QCheckBox(col, gridContainer);
        if (col == QLatin1String("text_cn") || col == QLatin1String("text_en"))
        {
            cb->setChecked(true);
        }
        m_extractLangChecks.push_back(cb);
        grid->addWidget(cb, idx / cols, idx % cols);
        ++idx;
    }
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls())
    {
        event->acceptProposedAction();
    }
    else
    {
        event->ignore();
    }
}

void MainWindow::dropEvent(QDropEvent *event)
{
    if (!event->mimeData()->hasUrls())
    {
        event->ignore();
        return;
    }
    QList<QUrl> urls = event->mimeData()->urls();
    if (urls.isEmpty())
    {
        event->ignore();
        return;
    }
    const QString p = urls.first().toLocalFile();
    QFileInfo fi(p);
    if (fi.isDir())
    {
        m_tabs->setCurrentIndex(0);
        m_pathEdit->setText(p);
        setCurrentPath(p);
        log(QString("拖拽目录：%1").arg(p));
        event->acceptProposedAction();
    }
    else if (fi.suffix().toLower() == "csv")
    {
        m_tabs->setCurrentIndex(1);
        if (m_csvInputEdit)
            m_csvInputEdit->setText(p);
        log(QString("拖拽CSV：%1").arg(p));
        event->acceptProposedAction();
    }
    else
    {
        event->ignore();
    }
}

void MainWindow::onNewFolder()
{
    const QString base = currentDirPath();
    bool ok = false;
    const QString name = QInputDialog::getText(this, "新建文件夹", "名称：", QLineEdit::Normal, "NewFolder", &ok);
    if (!ok || name.isEmpty())
        return;
    QDir dir(base);
    if (dir.mkdir(name))
    {
        log(QString("已创建文件夹：%1").arg(dir.absoluteFilePath(name)));
        onRefresh();
    }
    else
    {
        QMessageBox::critical(this, "创建失败", "无法创建文件夹");
    }
}

void MainWindow::onRename()
{
    QStringList files = selectedFilePaths();
    if (files.size() != 1)
    {
        QMessageBox::information(this, "重命名", "请选中一项进行重命名");
        return;
    }
    const QString src = files.first();
    QFileInfo fi(src);
    bool ok = false;
    const QString newName = QInputDialog::getText(this, "重命名", "新名称：", QLineEdit::Normal, fi.fileName(), &ok);
    if (!ok || newName.isEmpty())
        return;
    const QString dst = fi.dir().absoluteFilePath(newName);
    if (QFile::rename(src, dst))
    {
        log(QString("已重命名：%1 -> %2").arg(src, dst));
        onRefresh();
    }
    else
    {
        QMessageBox::critical(this, "重命名失败", "无法重命名文件或文件夹");
    }
}

void MainWindow::onDelete()
{
    QStringList files = selectedFilePaths();
    if (files.isEmpty())
    {
        QMessageBox::information(this, "删除", "请选中至少一项进行删除");
        return;
    }
    if (QMessageBox::question(this, "确认删除", QString("将删除 %1 项，是否继续？").arg(files.size())) != QMessageBox::Yes)
    {
        return;
    }
    int okCount = 0;
    foreach (const QString &p, files)
    {
        QFileInfo fi(p);
        bool ok = false;
        if (fi.isDir())
        {
            QDir dir(p);
            ok = dir.removeRecursively();
        }
        else
        {
            ok = QFile::remove(p);
        }
        if (ok)
            okCount++;
    }
    log(QString("删除完成：成功 %1 / 总计 %2").arg(okCount).arg(files.size()));
    onRefresh();
}

void MainWindow::onCopy()
{
    QStringList files = selectedFilePaths();
    if (files.isEmpty())
    {
        QMessageBox::information(this, "复制", "请选中至少一项进行复制");
        return;
    }
    const QString dstDir = QFileDialog::getExistingDirectory(this, "选择目标目录", currentDirPath());
    if (dstDir.isEmpty())
        return;
    int okCount = 0;
    foreach (const QString &p, files)
    {
        QFileInfo fi(p);
        const QString dst = QDir(dstDir).absoluteFilePath(fi.fileName());
        bool ok = false;
        if (fi.isDir())
        {
            // 简化：目录复制为创建同名目录，不做递归复制
            ok = QDir(dstDir).mkdir(fi.fileName());
        }
        else
        {
            ok = QFile::copy(p, dst);
        }
        if (ok)
            okCount++;
    }
    log(QString("复制完成：成功 %1 / 总计 %2").arg(okCount).arg(files.size()));
    onRefresh();
}

void MainWindow::onMove()
{
    QStringList files = selectedFilePaths();
    if (files.isEmpty())
    {
        QMessageBox::information(this, "移动", "请选中至少一项进行移动");
        return;
    }
    const QString dstDir = QFileDialog::getExistingDirectory(this, "选择目标目录", currentDirPath());
    if (dstDir.isEmpty())
        return;
    int okCount = 0;
    foreach (const QString &p, files)
    {
        QFileInfo fi(p);
        const QString dst = QDir(dstDir).absoluteFilePath(fi.fileName());
        bool ok = QFile::rename(p, dst);
        if (ok)
            okCount++;
    }
    log(QString("移动完成：成功 %1 / 总计 %2").arg(okCount).arg(files.size()));
    onRefresh();
}
