#include "csv_lang_plugin.h"
#include "csv_parser.h"
#include "text_extractor.h"
#include "diff_utils.h"
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QTextCodec>
#include <QDateTime>
#include <QRegularExpression>
#include <QJsonDocument>

// Forward declaration for function used before its definition
static QString readFileAutoCodec(const QString &path, QString &chosenCodec, bool &utf8Bom);

namespace CsvLangPlugin
{

    static QString ensureLogsDir(const QString &root)
    {
        QDir r(root);
        QString logs = r.absoluteFilePath(QStringLiteral("logs"));
        QDir().mkpath(logs);
        return QDir(logs).absoluteFilePath(QStringLiteral("csv_lang_plugin.log"));
    }

    static QString backupsSessionDir(const QString &root)
    {
        QDir r(root);
        QString base = r.absoluteFilePath(QStringLiteral(".csv_lang_backups"));
        QDir().mkpath(base);
        QString ts = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd_HHmmss"));
        QString sess = QDir(base).absoluteFilePath(ts);
        QDir().mkpath(sess);
        return sess;
    }

    static bool inMacroContext(const QString &text, int matchStart)
    {
        // Skip if the initializer appears within a macro body (naive heuristic)
        int lineStart = text.lastIndexOf(QLatin1Char('\n'), matchStart);
        if (lineStart < 0)
            lineStart = 0;
        int prevDefine = text.lastIndexOf(QStringLiteral("#define"), matchStart);
        if (prevDefine < 0)
            return false;
        // If #define is after last newline, we consider match within macro
        return prevDefine > lineStart;
    }

    static QStringList discoverLangOrder(const QString &root, const QString &alias)
    {
        return TextExtractor::discoverLanguageColumns(root, QStringList{QStringLiteral(".h"), QStringLiteral(".hpp"), QStringLiteral(".c"), QStringLiteral(".cpp")}, alias);
    }

    static QString replaceInitializerBodyPreservingFormat(const QString &body,
                                                          const QStringList &structLangs,
                                                          const QStringList &csvValues,
                                                          const QMap<QString, int> &colMap)
    {
        // Tokenize literals and NULL while preserving separators
        QRegularExpression reTok(QStringLiteral(R"("([^"\\]|\\.)*"|NULL)"), QRegularExpression::DotMatchesEverythingOption);
        QString out = body;
        QList<QPair<int, int>> spans; // start,end of tokens in out
        auto it = reTok.globalMatch(out);
        while (it.hasNext())
        {
            auto m = it.next();
            spans << qMakePair(m.capturedStart(), m.capturedEnd());
        }
        // Map struct language index to csvValues
        for (int i = 0; i < structLangs.size() && i < spans.size(); ++i)
        {
            QString lang = structLangs[i];
            if (lang.startsWith(QLatin1String("text_")))
                lang = lang.mid(5);
            if (!colMap.contains(lang))
                continue;
            int csvIdx = colMap.value(lang);
            if (csvIdx < 0 || csvIdx >= csvValues.size())
                continue;
            QString newLit = QStringLiteral("\"%1\"").arg(csvValues[csvIdx]);
            int start = spans[i].first;
            int end = spans[i].second;
            out.replace(start, end - start, newLit);
            int delta = newLit.size() - (end - start);
            // adjust subsequent spans
            for (int k = i + 1; k < spans.size(); ++k)
            {
                spans[k].first += delta;
                spans[k].second += delta;
            }
        }
        return out;
    }

    CsvProcessStats applyTranslations(const QString &projectRoot,
                                      const QString &csvPath,
                                      const QJsonObject &config)
    {
        CsvProcessStats stats;
        QString logPath = ensureLogsDir(projectRoot);
        QFile logF(logPath);
        logF.open(QIODevice::Append);
        QTextStream log(&logF);
        log.setCodec("UTF-8");
        QString sessDir = backupsSessionDir(projectRoot);
        QString diffPath = QDir(projectRoot).absoluteFilePath(QStringLiteral("logs/csv_lang_plugin.diff"));
        QFile diffF(diffPath);
        diffF.open(QIODevice::WriteOnly | QIODevice::Truncate);
        QTextStream diffOut(&diffF);
        diffOut.setCodec("UTF-8");

        log << QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"))
            << QStringLiteral(" BEGIN csv import root=") << projectRoot << QStringLiteral(" csv=") << csvPath << QStringLiteral("\n");

        QString err;
        QList<CsvRow> rows = Csv::parseFile(csvPath, err);
        if (!err.isEmpty())
        {
            log << QStringLiteral("CSV解析失败: ") << err << QStringLiteral("\n");
            stats.failCount = 0;
            stats.logPath = logPath;
            stats.diffPath = diffPath;
            stats.outputDir = sessDir;
            logF.close();
            diffF.close();
            return stats;
        }

        // config
        QString aliasHint = config.value(QStringLiteral("struct_alias")).toString();
        bool dryRun = config.value(QStringLiteral("dry_run")).toBool();
        QJsonObject mapObj = config.value(QStringLiteral("column_mapping")).toObject();
        QMap<QString, int> colMap;
        for (auto it = mapObj.begin(); it != mapObj.end(); ++it)
            colMap[it.key()] = it.value().toInt();

        for (const CsvRow &r : rows)
        {
            QString absPath = r.sourcePath;
            if (QDir::isRelativePath(absPath))
                absPath = QDir(projectRoot).absoluteFilePath(absPath);
            QFileInfo fi(absPath);
            if (!fi.exists() || !fi.isFile())
            {
                stats.failedFiles << absPath;
                stats.failCount++;
                log << QStringLiteral("  路径无效: ") << absPath << QStringLiteral("\n");
                continue;
            }
            QFile f(absPath);
            if (!f.open(QIODevice::ReadOnly))
            {
                stats.failedFiles << absPath;
                stats.failCount++;
                log << QStringLiteral("  无法读取: ") << absPath << QStringLiteral("\n");
                continue;
            }
            f.close();
            QString codec;
            bool bom = false;
            QString text = readFileAutoCodec(absPath, codec, bom);
            if (text.isEmpty())
            {
                stats.failedFiles << absPath;
                stats.failCount++;
                log << QStringLiteral("  无法解码: ") << absPath << QStringLiteral("\n");
                continue;
            }

            // find initializer of variableName around lineNumber
            QRegularExpression reInitVar(QStringLiteral(R"((static\s+)?const\s+(\w+)\s+%1\s*=\s*\{(.*?)\};)").arg(QRegularExpression::escape(r.variableName)),
                                         QRegularExpression::DotMatchesEverythingOption);
            auto it = reInitVar.globalMatch(text);
            bool matched = false;
            int bestStart = -1;
            int bestEnd = -1;
            QString alias;
            while (it.hasNext())
            {
                auto m = it.next();
                int s = m.capturedStart(3);
                int e = m.capturedEnd(3);
                int lineAt = text.left(s).count(QLatin1Char('\n')) + 1;
                if (qAbs(lineAt - r.lineNumber) <= 50)
                { // near anchor
                    if (inMacroContext(text, s))
                    {
                        continue;
                    }
                    matched = true;
                    bestStart = s;
                    bestEnd = e;
                    alias = m.captured(2);
                    break;
                }
            }
            if (!matched)
            {
                stats.skippedFiles << absPath;
                stats.skipCount++;
                log << QStringLiteral("  跳过(未匹配初始化/宏): ") << absPath << QStringLiteral("\n");
                continue;
            }

            QStringList structLangs = aliasHint.isEmpty() ? discoverLangOrder(projectRoot, alias) : discoverLangOrder(projectRoot, aliasHint);
            if (structLangs.isEmpty())
            {
                stats.skippedFiles << absPath;
                stats.skipCount++;
                log << QStringLiteral("  跳过(未发现语言列): ") << absPath << QStringLiteral("\n");
                continue;
            }

            QString before = text;
            QString body = text.mid(bestStart, bestEnd - bestStart);
            QString newBody = replaceInitializerBodyPreservingFormat(body, structLangs, r.values, colMap);
            if (newBody == body)
            {
                stats.skippedFiles << absPath;
                stats.skipCount++;
                log << QStringLiteral("  跳过(无变更): ") << absPath << QStringLiteral("\n");
                continue;
            }
            QString after = text;
            after.replace(bestStart, bestEnd - bestStart, newBody);

            // write diff
            diffOut << DiffUtils::unifiedDiff(absPath, before, after);

            // backup and write
            QString rel = QDir(projectRoot).relativeFilePath(absPath);
            QString backupPath = QDir(sessDir).absoluteFilePath(rel);
            QDir().mkpath(QFileInfo(backupPath).dir().absolutePath());
            QFile bf(backupPath);
            if (bf.open(QIODevice::WriteOnly | QIODevice::Truncate))
            {
                QTextStream bts(&bf);
                bts.setCodec("UTF-8");
                bts << before;
                bf.close();
            }
            if (!dryRun)
            {
                if (f.open(QIODevice::WriteOnly | QIODevice::Truncate))
                {
                    // 保留原文件编码与 UTF-8 BOM 状态
                    if (bom && codec == QStringLiteral("UTF-8"))
                        f.write("\xEF\xBB\xBF");
                    QTextStream wr(&f);
                    wr.setCodec(codec.toUtf8().constData());
                    wr << after;
                    f.close();
                    stats.successFiles << absPath;
                    stats.successCount++;
                    log << QStringLiteral("  修改: ") << rel << QStringLiteral("\n");
                }
            }
            else
            {
                stats.successFiles << absPath;
                stats.successCount++;
                log << QStringLiteral("  预览修改: ") << rel << QStringLiteral("\n");
            }
        }

        log << QStringLiteral("成功:") << stats.successCount << QStringLiteral(" 跳过:") << stats.skipCount << QStringLiteral(" 失败:") << stats.failCount << QStringLiteral("\n");
        log << QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss")) << QStringLiteral(" END\n\n");
        logF.close();
        diffF.close();
        stats.logPath = logPath;
        stats.diffPath = diffPath;
        stats.outputDir = sessDir;
        return stats;
    }

}
    static QString decodeWithCodec(const QByteArray &data, const char *name)
    {
        QTextCodec *c = QTextCodec::codecForName(name);
        return c ? c->toUnicode(data) : QString();
    }

    // 自动编码检测：返回文本，并输出所选编码与是否存在 UTF-8 BOM
    static QString readFileAutoCodec(const QString &path, QString &chosenCodec, bool &utf8Bom)
    {
        chosenCodec.clear();
        utf8Bom = false;
        QFile f(path);
        if (!f.open(QIODevice::ReadOnly))
            return QString();
        QByteArray data = f.readAll();
        f.close();

        if (data.startsWith("\xEF\xBB\xBF"))
        {
            utf8Bom = true;
            chosenCodec = QStringLiteral("UTF-8");
            return QString::fromUtf8(data.constData() + 3, data.size() - 3);
        }
        if (data.size() >= 2 && (uchar)data[0] == 0xFF && (uchar)data[1] == 0xFE)
        {
            chosenCodec = QStringLiteral("UTF-16LE");
            QTextCodec *c = QTextCodec::codecForName("UTF-16LE");
            return c ? c->toUnicode(data) : QString();
        }
        if (data.size() >= 2 && (uchar)data[0] == 0xFE && (uchar)data[1] == 0xFF)
        {
            chosenCodec = QStringLiteral("UTF-16BE");
            QTextCodec *c = QTextCodec::codecForName("UTF-16BE");
            return c ? c->toUnicode(data) : QString();
        }

        auto countReplacement = [](const QString &s) -> int {
            int cnt = 0;
            for (int i = 0; i < s.size(); ++i)
                if (s.at(i).unicode() == 0xFFFD)
                    ++cnt;
            return cnt;
        };

        QString utf8 = decodeWithCodec(data, "UTF-8");
        int repUtf8 = countReplacement(utf8);
        QString gb18030 = decodeWithCodec(data, "GB18030");
        int repGb18030 = countReplacement(gb18030);
        QString gbk = decodeWithCodec(data, "GBK");
        int repGbk = countReplacement(gbk);
        QString gb2312 = decodeWithCodec(data, "GB2312");
        int repGb2312 = countReplacement(gb2312);

        // 选择替换字符最少的解码结果；持平时偏好 GB18030
        QString best = gb18030;
        int minRep = repGb18030;
        chosenCodec = QStringLiteral("GB18030");
        auto consider = [&](const QString &s, int rep, const QString &codec) {
            if (rep < minRep)
            {
                minRep = rep;
                best = s;
                chosenCodec = codec;
            }
        };
        consider(utf8, repUtf8, QStringLiteral("UTF-8"));
        consider(gbk, repGbk, QStringLiteral("GBK"));
        consider(gb2312, repGb2312, QStringLiteral("GB2312"));
        return best;
    }