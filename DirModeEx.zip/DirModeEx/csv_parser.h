/**
 * @file csv_parser.h
 * @brief CSV 解析模块接口（CSV Parser Module APIs）
 *
 * 功能名称：CSV 解析（CSV Parsing）
 * 主要用途：
 * - 解析带引号与转义的 CSV 文本；
 * - 输出行结构，支持源位置与变量名；
 *
 * 使用示例：
 *  QString err; auto rows = Csv::parseFile(csvPath, err);
 *  if (!err.isEmpty()) { /* handle error */ }
 */
#ifndef CSV_PARSER_H
#define CSV_PARSER_H

#include <QString>
#include <QStringList>
#include <QList>

/**
 * @brief CSV 行结构（CSV Row structure）
 * @details 包含源文件位置、变量名以及按列顺序的文本值。
 */
struct CsvRow {
    QString sourcePath;   // absolute or project-relative path
    int lineNumber{0};    // line anchor for initializer
    QString variableName; // variable identifier in C source
    QStringList values;   // language texts in CSV order
};

namespace Csv {

/**
 * @brief 严格 CSV 解析，支持引号、转义与 UTF-8（Strict CSV parsing with quotes/escapes, UTF-8）
 * @param csvPath 输入 CSV 文件路径
 * @param error 若失败，返回错误消息（中文优先，含英文）
 * @return CsvRow 列表；包含源位置与变量名（若可用）
 */
QList<CsvRow> parseFile(const QString &csvPath, QString &error);

}

#endif // CSV_PARSER_H